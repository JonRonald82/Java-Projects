# Java-Projects

Basic to high-level projects based on java.
Contemplating and complimenting our daily life in its own way.

Java is a high-level, class-based, object-oriented programming language that is designed to have as few implementation dependencies as possible.
It brings many possibility and flexibility with each time you work on it. 
