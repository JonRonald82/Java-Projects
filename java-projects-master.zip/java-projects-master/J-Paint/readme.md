# Java - Paint

A simple Drawing Application developed using Java

1. Main Module :<br>
  <a href="https://github.com/Aman-Yadav-1/java-projects/blob/master/J-Paint/canvas/Main.java">Main.java</a><br>
  The Main class contains the main function to start the program. Here we will just call the function to be executed<br><br>
2. Project Module :<br>
    <a href="https://github.com/Aman-Yadav-1/java-projects/blob/master/J-Paint/canvas/Canvas.java">Canvas.java</a><br>
    The Class contains the whole project. Here we can draw, erase, save and do many other operations.
  
<img src="https://github.com/Aman-Yadav-1/java-projects/blob/master/J-Paint/J-paint.png" width="700" height="450"/>
<img src="https://github.com/Aman-Yadav-1/java-projects/blob/master/J-Paint/paintwithjava.png" width="700" height="450"/>
