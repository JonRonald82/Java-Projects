# Calculator

A Simple calculator project that lets you enter your own inputs and select from given options,
User has to give two numbers as input and 
#  One has to-
    select 0 for addition
           1 for subtraction
           2 for multiplication
           3 for division
   and if none of input is correct the code executes the paramater where it prints the Invalid input case.
#

Main file is saved in src folder with <a href="https://github.com/Aman-Yadav-1/java-projects/blob/master/calculator/src/Main.java">Main.java</a>
