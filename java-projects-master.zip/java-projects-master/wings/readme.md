# Wings Game

A simple flappy bird type game that responds to user activities in the game.

Features:
1. Use the spacebar key to fly high
2. Create obstacles and birds with the help of Java Swing
3. Keep updating the current score and the high score as the bird passes by an obstacle


<a href="https://github.com/Aman-Yadav-1/java-projects/blob/master/wings/main.java">Source Code</a><br><br>
<img src="https://github.com/Aman-Yadav-1/java-projects/blob/master/wings/wings_homess.png" width="400" height="300"/>
<img src="https://github.com/Aman-Yadav-1/java-projects/blob/master/wings/ingame_ss.jpg" width="400" height="300"/>
